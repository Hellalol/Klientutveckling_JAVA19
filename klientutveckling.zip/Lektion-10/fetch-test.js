if (Modernizr.fetch) {
  console.log("Fetch API is supported");
} else {
  console.error("Fetch API is not supported");
}