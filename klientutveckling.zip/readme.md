# Klientutveckling
## Teacher: Mahmud Al Hakim
### Nackademin - Stockholm - Sweden